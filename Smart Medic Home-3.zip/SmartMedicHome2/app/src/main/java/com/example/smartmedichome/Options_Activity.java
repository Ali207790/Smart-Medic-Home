package com.example.smartmedichome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.auth.FirebaseAuth;

public class Options_Activity extends AppCompatActivity {

    Button searchmedicine;
    Button scanner;
    Button bookmarks;
   // Button logout;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_options);

        searchmedicine = findViewById(R.id.searchmedicine);
        scanner = findViewById(R.id.scanner);
        bookmarks = findViewById(R.id.bookmarks);
     //   logout = findViewById(R.id.logout);

        searchmedicine.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Options_Activity.this, Search_Activity.class);
                startActivity(intent);
            }
        });

        scanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Options_Activity.this, BQScanner_Activity.class);
                startActivity(intent);
            }
        });

        bookmarks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Options_Activity.this, Bookmarks_Activity.class);
                startActivity(intent);
            }
        });

       // logout.setOnClickListener(new View.OnClickListener() {
          //  @Override
          //  public void onClick(View v) {
            //    FirebaseAuth.getInstance().signOut();
             //   Intent intent = new Intent(Options_Activity.this, SignIn_Activity.class);
              //  startActivity(intent);
           // }
       // });

    }

}