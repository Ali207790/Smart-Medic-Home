package com.example.smartmedichome;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SearchView;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class Search_Activity extends AppCompatActivity {

    SearchView searchView;
    ListView listView;
    DatabaseReference databaseReference;
    List<String>  title_list, Info_list;

    //ArrayList<String> list;
    ArrayAdapter<String> adapter;
    Infoget infoget;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);


        getWindow().setFlags(
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
        );


        getSupportActionBar().setTitle("List Of Medicines");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);


        searchView = (SearchView) findViewById(R.id.searchview);
        listView = (ListView) findViewById(R.id.listview);
        databaseReference = FirebaseDatabase.getInstance().getReference("Description");
        infoget = new Infoget();
        title_list = new ArrayList<>();
        Info_list = new ArrayList<>();
        adapter = new ArrayAdapter<>(this,R.layout.activity_item, R.id.item_txt, title_list);

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                title_list.clear();
                Info_list.clear();

               for (DataSnapshot ds : dataSnapshot.getChildren()){
                   infoget = ds.getValue(Infoget.class);
                   if (infoget != null) {
                       title_list.add(infoget.getTitle());
                   }
                   if (infoget != null) {
                       Info_list.add(infoget.getInfo());
                   }

               }
               listView.setAdapter(adapter);
               listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                   @Override
                   public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                       Intent intent = new Intent(Search_Activity.this, Information_Activity.class);
                       String oneitem = Info_list.get(position);
                       intent.putExtra("key", oneitem);
                       startActivity(intent);
                   }
               });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


//        list = new ArrayList<String>();

  //      list.add("Panadol");
    //    list.add("Brufen");
      //  list.add("Rizek");
        //list.add("Arinac");
       // list.add("Amlodipine");
       // list.add("intramuscular");
       // list.add("Alendronate");
        //list.add("Searle");
       // list.add("Folic_Acid");
        //list.add("Safi");
        //list.add("Mucaine");
        //list.add("Augmentin");
        //list.add("Calpol");
        //list.add("Dolphin");
        //list.add("Dollar");



        //adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, list);
        //listView.setAdapter(adapter);

        //listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
          //  @Override
           // public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

             //   String Templistview;
               // Templistview = list.get(position).toString();
                //Intent intent = new Intent(Search_Activity.this, Information_Activity.class);
                //intent.putExtra("listviewclickvalue", list);

                //startActivity(intent);
           // }
        //});

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                adapter.getFilter().filter(newText);
                return false;
            }
        });




    }

}