package com.example.smartmedichome;

public class Infoget {

    String title;
    String Info;

    public Infoget() {
    }

    public Infoget(String title, String info) {
        this.title = title;
        this.Info = info;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getInfo() {
        return Info;
    }

    public void setInfo(String info) {
        this.Info = info;
    }
}
