package com.example.smartmedichome;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Information_Activity extends AppCompatActivity {

    TextView textView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        getSupportActionBar().setTitle("Description");


        textView = findViewById(R.id.info_txt);

        String receiveitem = getIntent().getStringExtra("key");
        textView.setText(receiveitem);



    }
}