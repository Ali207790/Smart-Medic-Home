package com.example.smartmedichome;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class Bookmarks_Activity extends AppCompatActivity {

    Button alarm_1, alarm_2, alarm_3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bookmarks);

        alarm_1 = findViewById(R.id.alarm_1);
        alarm_2 = findViewById(R.id.alarm_2);
        alarm_3 = findViewById(R.id.alarm_3);

        alarm_1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bookmarks_Activity.this,Alarm1_Activity.class);
                startActivity(intent);
            }
        });

        alarm_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bookmarks_Activity.this, Alarm2_Activity.class);
                startActivity(intent);
            }
        });

        alarm_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Bookmarks_Activity.this, Alarm3_Activity.class);
                startActivity(intent);
            }
        });



    }
}